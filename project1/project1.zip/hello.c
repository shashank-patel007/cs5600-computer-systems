/*
 * file: hello.c - project1-part-2 micro-program
 */

extern void print(char *buf);

int main(void)
{
    print("Hello world!\n");
    return 0;
}

