/*
 * file: wait.c - project-1-part-1 microprogram
 */

int main(int argc, char **argv)
{
	int i, j;
	for (i = 0; i < 10000; i++)
		for (j = 0; j < 100000; j++)
			;
        return 0;
}

