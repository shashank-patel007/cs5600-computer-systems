#ifndef CAESAR_H
#define CAESAR_H

void encode(char *plaintext, int key);
void decode(char *ciphertext, int key);

#endif